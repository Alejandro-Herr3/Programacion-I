﻿using Domain.Enums;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public class Empleado
    {
        public int Id { get; set; }

        public string DNI { get; set; }

        public string Nombres { get; set; }

        public string Apellidos { get; set; }

        public decimal Salario { get; set; }

        public NivelAcademico NivelAcademico { get; set; }

        public Genero Genero { get; set; }

        #region Clases Internas
        public class SalarioComparer : IComparer<Empleado>
        {
            public int Compare(Empleado e1, Empleado e2)
            {
                if (e1.Salario > e2.Salario)
                {
                    return 1;
                }
                if (e1.Salario < e2.Salario)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
            }
        }

        public class NivelAcademicoComparer : IComparer<Empleado>
        {
            public int Compare(Empleado nA1, Empleado nA2)
            {
                if (nA1.NivelAcademico > nA2.NivelAcademico)
                {
                    return 1;
                }
                if (nA1.NivelAcademico < nA2.NivelAcademico)
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
            }
        }

        public class ApellidosComparer : IComparer<Empleado>
        {
            public int Compare(Empleado x, Empleado y)
            {
                return x.Apellidos.CompareTo(y.Apellidos);
            }
        }

        #endregion
    }
}
