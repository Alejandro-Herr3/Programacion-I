﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    class SalarioFragmentado
    {
        public int Miles { get; set; }

        public int Centenas { get; set; }

        public int Decenas { get; set; }

        public int Unidades { get; set; }


    }
}
