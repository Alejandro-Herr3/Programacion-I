﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    class Celular
    {
        private string Marca { get; set; }
        private int Modelo { get; set; }
        private decimal Precio { get; set; }
        private string Descripcion { get; set; }
        private string Bateria { get; set; }
        private String Pantalla { get; set; }
        private string Entrada { get; set; }
        private int CantidadCamaras { get; set; }
        private int EspacioAlmacenamiento { get; set; }
        private int MemoriaRam { get; set; }

    }
}
