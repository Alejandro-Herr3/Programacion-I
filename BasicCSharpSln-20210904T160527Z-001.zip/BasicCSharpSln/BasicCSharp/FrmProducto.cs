﻿using Domain;
using Domain.Enums;
using InfraEstructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCSharp
{
    public partial class FrmProducto : Form
    {
        private ProductoModel model;
        public FrmProducto()
        {
            InitializeComponent();
            model = new ProductoModel();
        }

        private void BtnMostrar_Click(object sender, EventArgs e)
        {
            string nombre, descripcion;
            int codigo, cantidad;
            decimal precio;
            DateTime Caducidad;

            nombre = txtNombre.Text;
            descripcion = txtDescripcion.Text;
            int.TryParse(txtCodigo.Text, out codigo);
            int.TryParse(txtCantidad.Text, out cantidad);
            decimal.TryParse(txtPrecio.Text, out precio);
            DateTime.TryParse(txtCaducidad.Text, out Caducidad);


            Producto producto = new Producto
            {
                Codigo = codigo,
                Nombre = nombre,
                Descripcion = descripcion,
                Cantidad = cantidad,
                Precio = precio,
                Caducidad = Caducidad,
                UnidadMedida = (UnidadMedida)Enum.GetValues(typeof(UnidadMedida)).GetValue(cmbUnidadMedida.SelectedIndex)
            };

            PrintProducto(producto);
            model.Add(producto);
            ClenTextBox();
        }



        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            
                
        }

        #region Metodos

        private void PrintProducto(Producto p)
        {
            string text = $@"Cod:{p.Codigo}
                          Nombre:{p.Nombre}
                     Descripcion:{p.Descripcion}
                        Cantidad:{p.Cantidad}
                          Precio:{p.Precio}
                       Caducidad:{p.Caducidad}
                Unidad de Medida:{p.UnidadMedida}";
            MessageBox.Show(text, "Mensaje de informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ClenTextBox()
        {
            txtCodigo.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtDescripcion.Text = string.Empty;
            txtCantidad.Text = string.Empty;
            txtPrecio.Text = string.Empty;
            txtCaducidad.Text = string.Empty;
            cmbUnidadMedida = default;
        }

        private void SearchId(int codigo) 
        { 
            for (int i = 0; i < )
            {

            }
        }
        #endregion
    }
}
