﻿using Domain;
using Domain.Enums;
using InfraEstructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCSharp
{
    public partial class Form1 : Form
    {
        public int Id { get; set; }
        private EmpleadoModel eModel;
        public Form1()
        {
            eModel = new EmpleadoModel();
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string dni, nombres, apellidos;
            decimal salario;

            dni = txtDni.Text;
            nombres = txtNombres.Text;
            apellidos = txtApellidos.Text;

            ValidarDatosEmpleado(dni, nombres, apellidos, txtSalario.Text);

            if (!decimal.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show($@"Error el salario {txtSalario.Text} no se pudo convertir", 
                                   "Mensaje de error", 
                                   MessageBoxButtons.OK, 
                                   MessageBoxIcon.Error);
                return;
            }
            
            Empleado emp = new Empleado()
            {
                Id = ++Id,
                DNI = dni,
                Nombres = nombres,
                Apellidos = apellidos,
                Salario = salario,
                NivelAcademico = (NivelAcademico) Enum.GetValues(typeof(NivelAcademico)).GetValue(cmbNivel.SelectedIndex),
                Genero = (Genero) Enum.GetValues(typeof(Genero)).GetValue(cmbGenero.SelectedIndex)
            };

            eModel.Add(emp);

            MessageBox.Show($@"
                            Id: {emp.Id} {Environment.NewLine}
                           DNI: {emp.DNI} {Environment.NewLine}
                       Nombres: {emp.Nombres} {Environment.NewLine}
                     Apellidos: {emp.Apellidos} {Environment.NewLine}
                       Salario: {emp.Salario} {Environment.NewLine}
                        Count:{eModel.GetEmpleados().Length}");

            CleanTextbox();
        }

        private void CleanTextbox()
        {
            txtDni.Text = string.Empty;
            txtNombres.Text = string.Empty;
            txtApellidos.Text = string.Empty;
            txtSalario.Text = string.Empty;
        }

        public void ValidarDatosEmpleado(string dni, string nombres, string apellido, string salario)
        {
            string patternDni = @"\d{3}-\d{6}-\d{4}[A-Z]{1}";

        }

        private void BtnFragmentar_Click(object sender, EventArgs e)
        {
            decimal salario;
            decimal.TryParse(txtSalario.Text, out salario);
            FragmentarSalario(salario);
        }
        
        public void FragmentarSalario(decimal salario)
        {
            int x = 0;
            for ( decimal i = salario; i >= 999; i -= 1000)
            {
                x++;
            }
            MessageBox.Show($"Miles = {x}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
           MessageBox.Show($"Salario maximo:{eModel.GetSalarioMaximo()}");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Salario minimo:{eModel.GetSalarioMinimoProfe()}");
        }

        private void BtnEncimaProm_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Salario por encima del promedio: {eModel.GetSalarioEncimaPromedio()}");
        }

        private void BtnDebajoProm_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Salario por debajo del promedio: {eModel.GetSalarioDebajoPromedio()}");
        }

        private void BtnPromSalarios_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"El promedio de los salarios es:{eModel.GetSalarioPromedio()}");
        }
    }
}
