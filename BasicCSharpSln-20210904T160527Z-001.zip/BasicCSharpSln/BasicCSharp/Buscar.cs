﻿using InfraEstructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCSharp
{
    public partial class Buscar : Form
    {
        private ProductoModel pmodel;
        public Buscar()
        {
            InitializeComponent();
             pmodel = new ProductoModel();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {

        }
    }
}
